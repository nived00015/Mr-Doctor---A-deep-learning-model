import pandas as pd
from keras.models import load_model
import numpy as np
from tkinter import *

df = pd.read_csv('Testing.csv')

symptoms_list= list(df.drop('prognosis',axis=1).columns)

disease_list= list(pd.get_dummies(df['prognosis']).columns)

symptoms_intial = {symptom:0 for symptom in symptoms_list}
model= load_model('model')

win = Tk()
win.title('Mr Digital Doctor')
def get_value():
    symptom_data=str(clicked.get())
    symptoms_intial[symptom_data] = 1
def predict_disease():
    symptom_decode = np.array([symptoms_intial[i] for i in symptoms_intial.keys()])
    y_pred = model.predict(np.expand_dims(symptom_decode, axis=0))
    pred_index = np.argmax(y_pred[0])
    print(f'The disease is most probably {disease_list[pred_index]} with a confidence of {y_pred[0][pred_index] * 100}%')
    label_1 = Label(win,text=f'The disease is most probably {disease_list[pred_index]} with a confidence of {y_pred[0][pred_index] * 100}%')
    label_1.pack()
win.geometry('300x300')
clicked = StringVar()
clicked.set('Set your symptom')
options= OptionMenu(win,clicked,*symptoms_list)
options.pack()
btn = Button(win,text='Add Symptoms',command=get_value)
btn.pack(expand=True)
bt1 = Button(win,text='Find Disease',command=predict_disease)
bt1.pack()
bt2 = Button(win,text='Exit',command=win.destroy)
bt2.pack()
win.mainloop()








